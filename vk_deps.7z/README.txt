To run the engine with the Vulkan renderer place d3d11.dll and dxgi.dll next to DllEngineLoader.exe

For OSD please visit https://github.com/Joshua-Ashton/d9vk#hud